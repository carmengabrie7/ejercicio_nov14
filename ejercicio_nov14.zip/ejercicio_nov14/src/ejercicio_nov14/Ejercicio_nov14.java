package ejercicio_nov14;

import javax.swing.JOptionPane;


public class Ejercicio_nov14 {
    public static void mostrar(){
        for (int i = 0; i < 3; i++) {
        JOptionPane.showMessageDialog(null, "El nombre del empleado es:"+datos[i].getNombre());
        JOptionPane.showMessageDialog(null, "El genero del empleado es:"+datos[i].getGenero());
        JOptionPane.showMessageDialog(null, "La edad del empleado es:"+datos[i].getEdad());
        JOptionPane.showMessageDialog(null, "El salario del empleado es:"+datos[i].getSalario());
        JOptionPane.showMessageDialog(null, "La bonificación del empleado es:"+datos[i].getBonificacion());
        JOptionPane.showMessageDialog(null, "El salario final es:"+datos[i].getBonificacion()+datos[i].getSalario());
        }
    }
    
public static int salario_final(int indice){
    double salario= datos[indice].getSalario();
    for (int i = 0; i < 3; i++) {
        if(antiguedad <=5 && salario <= 18900){
            bonificacion[indice]=(int)(salario*0.10);
            
        }
        else if (antiguedad >=7 && salario > 25000 && salario<= 45000 ){
            bonificacion[indice]=(int)(salario*0.15);
        }
        else if (salario>45000){
            bonificacion[indice]=(int)(salario*0.20);
        }
        return bonificacion[indice];
    } 
}
    public static bonificacion datos[]=new bonificacion[3];
    public static int antiguedad;
    public static int bonificacion[]=new int[3];
    public static void main(String[] args) {
        
        String nombre,genero;
        int edad;
        double salario;
        
        for (int i = 0; i < 4; i++) {
            datos[1]=new bonificacion();
            nombre=JOptionPane.showInputDialog("Favor ingresar el nombre del empleado: ");
            datos[1].setNombre(nombre);
            genero=JOptionPane.showInputDialog("Favor ingresar el genero del empleado: ");
            datos[1].setGenero(genero);
            edad=Integer.parseInt(JOptionPane.showInputDialog("Favor ingresar la edad del empleado: "));
            datos[1].setEdad(edad);
            salario=Double.parseDouble(JOptionPane.showInputDialog("Favor ingresar el salario del empleado: "));
            datos[1].setSalario(salario);
            antiguedad=Integer.parseInt(JOptionPane.showInputDialog("Favor ingresar el tiempo que lleva trabajando como empleado: "));
            datos[1].setBonificacion(salario_final(i));
            
        }
        
        mostrar();
        
        
    }
    
}
